//
//  Tutorial10Tests.swift
//  Tutorial10Tests
//
//  Created by Vouching Cheav on 15/10/2026.
//

import Testing
@testable import Tutorial10

struct Tutorial10Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
