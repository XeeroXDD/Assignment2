//
//  ViewController.swift
//  Tutorial10
//
//  Created by Vouching Cheav on 15/10/2026.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var label: UILabel!

    // Location of sample.txt inside the app's Documents folder
    var fileURL: URL {
        FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("sample.txt")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        label.numberOfLines = 0
        label.text = "Loaded content will appear here"
    }

    // Save: write the text view's content to sample.txt
    @IBAction func saveTapped(_ sender: UIButton) {
        do {
            try textView.text.write(to: fileURL, atomically: true, encoding: .utf8)
            label.text = "Saved to sample.txt"
        } catch {
            label.text = "Save failed: \(error.localizedDescription)"
        }
        textView.resignFirstResponder()   // hide the keyboard
    }

    // Open: read sample.txt and show it in the label
    @IBAction func openTapped(_ sender: UIButton) {
        do {
            label.text = try String(contentsOf: fileURL, encoding: .utf8)
        } catch {
            label.text = "Couldn't open sample.txt. Save something first."
        }
    }
}

