//
//  CircleButtonViewController.swift
//  Tutorial10Exercise 2
//
//  Created by Vouching Cheav on 15/10/2026.
//

import UIKit

class CircleButton: UIButton {

    var isPlus = true              // true = "+", false = "−"
    var fillColor = UIColor.systemTeal

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }

        // 1. Draw the filled circle
        ctx.setFillColor(fillColor.cgColor)
        ctx.fillEllipse(in: rect.insetBy(dx: 2, dy: 2))

        // 2. Draw the white symbol
        let size = min(rect.width, rect.height)
        let half = size * 0.25          // half the length of each line
        let cx = rect.midX
        let cy = rect.midY

        ctx.setStrokeColor(UIColor.white.cgColor)

        if isPlus {
            ctx.setLineWidth(size * 0.025)                       // thin lines
            ctx.move(to: CGPoint(x: cx - half, y: cy))           // horizontal
            ctx.addLine(to: CGPoint(x: cx + half, y: cy))
            ctx.move(to: CGPoint(x: cx, y: cy - half))           // vertical
            ctx.addLine(to: CGPoint(x: cx, y: cy + half))
        } else {
            ctx.setLineWidth(size * 0.05)                        // thicker bar
            ctx.move(to: CGPoint(x: cx - half, y: cy))
            ctx.addLine(to: CGPoint(x: cx + half, y: cy))
        }

        ctx.strokePath()
    }
}
