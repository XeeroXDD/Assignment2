//
//  ViewController.swift
//  Tutorial10Exercise 2
//
//  Created by Vouching Cheav on 15/10/2026.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white

        let plusButton = CircleButton(frame: CGRect(x: 60, y: 200, width: 120, height: 120))
        plusButton.isPlus = true
        plusButton.fillColor = UIColor(red: 82/255, green: 183/255, blue: 177/255, alpha: 1)
        plusButton.backgroundColor = .clear
        plusButton.addTarget(self, action: #selector(plusTapped), for: .touchUpInside)
        view.addSubview(plusButton)

        let minusButton = CircleButton(frame: CGRect(x: 200, y: 200, width: 120, height: 120))
        minusButton.isPlus = false
        minusButton.fillColor = UIColor(red: 1, green: 17/255, blue: 70/255, alpha: 1)
        minusButton.backgroundColor = .clear
        minusButton.addTarget(self, action: #selector(minusTapped), for: .touchUpInside)
        view.addSubview(minusButton)
    }

    @objc func plusTapped()  { print("+ tapped") }
    @objc func minusTapped() { print("− tapped") }
}

