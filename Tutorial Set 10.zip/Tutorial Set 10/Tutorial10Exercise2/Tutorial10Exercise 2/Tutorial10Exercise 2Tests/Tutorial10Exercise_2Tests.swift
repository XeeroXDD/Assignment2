//
//  Tutorial10Exercise_2Tests.swift
//  Tutorial10Exercise 2Tests
//
//  Created by Vouching Cheav on 15/10/2026.
//

import Testing
@testable import Tutorial10Exercise_2

struct Tutorial10Exercise_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
        // Swift Testing Documentation
        // https://developer.apple.com/documentation/testing
    }

}
