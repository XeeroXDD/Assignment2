//
//  ViewController.swift
//  Tutorial10Exercise 3
//
//  Created by Vouching Cheav on 15/10/2026.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, UITextFieldDelegate {

    let mapView = MKMapView()
    let addressField = UITextField()
    let findButton = UIButton(type: .system)
    let geocoder = CLGeocoder()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground

        // Address input
        addressField.placeholder = "Enter an address"
        addressField.borderStyle = .roundedRect
        addressField.returnKeyType = .search
        addressField.delegate = self

        // Find button
        findButton.setTitle("Find", for: .normal)
        findButton.addTarget(self, action: #selector(findAddress), for: .touchUpInside)

        // Text field and button side by side
        let row = UIStackView(arrangedSubviews: [addressField, findButton])
        row.spacing = 8
        row.translatesAutoresizingMaskIntoConstraints = false
        mapView.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(row)
        view.addSubview(mapView)

        NSLayoutConstraint.activate([
            row.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
            row.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            row.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            findButton.widthAnchor.constraint(equalToConstant: 60),

            mapView.topAnchor.constraint(equalTo: row.bottomAnchor, constant: 12),
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // Pressing Return on the keyboard also searches
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        findAddress()
        return true
    }

    @objc func findAddress() {
        guard let address = addressField.text, !address.isEmpty else { return }
        addressField.resignFirstResponder()

        // Search for the address the same way the Maps app does
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = address

        MKLocalSearch(request: request).start { response, error in
            guard let item = response?.mapItems.first else {
                self.showAlert("Address not found")
                return
            }
            self.markOnMap(item.placemark.coordinate, title: item.name ?? address)
        }
    }

    func markOnMap(_ coordinate: CLLocationCoordinate2D, title: String) {
        mapView.removeAnnotations(mapView.annotations)   // clear the old pin

        let pin = MKPointAnnotation()
        pin.coordinate = coordinate
        pin.title = title
        mapView.addAnnotation(pin)

        // Zoom in to about 1 km around the pin
        let region = MKCoordinateRegion(center: coordinate,
                                        latitudinalMeters: 1000,
                                        longitudinalMeters: 1000)
        mapView.setRegion(region, animated: true)
    }

    func showAlert(_ message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
